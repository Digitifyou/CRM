<?php
// SECURITY CHECK: Ensure user is logged in
require_once __DIR__ . '/api/config.php'; 

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM - Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Training Academy CRM</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/students.php">Students</a></li>
                    <li class="nav-item"><a class="nav-link" href="/enrollments.php">Enrollments</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/settings.php">Settings</a></li>
                    <li class="nav-item"><a class="nav-link" href="/meta_ads.php">Meta Ads</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container">
        <h2 class="mb-4">System Settings</h2>

        <div class="row">
            <div class="col-md-3">
                <div class="list-group" id="settings-tabs" role="tablist">
                    <a class="list-group-item list-group-item-action active" id="courses-tab" data-bs-toggle="list" href="#courses-pane" role="tab">
                        <i class="bi bi-book me-2"></i> Course Management
                    </a>
                    <a class="list-group-item list-group-item-action" id="batches-tab" data-bs-toggle="list" href="#batches-pane" role="tab">
                        <i class="bi bi-calendar-event me-2"></i> Batch Management
                    </a>
                    <a class="list-group-item list-group-item-action" id="pipeline-tab" data-bs-toggle="list" href="#pipeline-pane" role="tab">
                        <i class="bi bi-diagram-3 me-2"></i> Pipeline Editor
                    </a>
                    <a class="list-group-item list-group-item-action" id="users-tab" data-bs-toggle="list" href="#users-pane" role="tab">
                        <i class="bi bi-people me-2"></i> User Management
                    </a>
                    <a class="list-group-item list-group-item-action" id="custom-fields-tab" data-bs-toggle="list" href="#custom-fields-pane" role="tab">
                        <i class="bi bi-list-columns-reverse me-2"></i> Custom Fields
                    </a>
                    <a class="list-group-item list-group-item-action" id="integrations-tab" data-bs-toggle="list" href="#integrations-pane" role="tab">
                        <i class="bi bi-globe me-2"></i> Integrations
                    </a>
                    <a class="list-group-item list-group-item-action" id="bulk-import-tab" data-bs-toggle="list" href="#bulk-import-pane" role="tab">
                        <i class="bi bi-cloud-upload me-2"></i> Bulk Import
                    </a>
                    </div>
            </div>
            <div class="col-md-9">
                <div class="tab-content">

                    <div class="tab-pane fade show active" id="courses-pane" role="tabpanel" aria-labelledby="courses-tab">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h3 class="mb-0">Manage Courses</h3>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                                <i class="bi bi-plus-lg"></i> Add New Course
                            </button>
                        </div>

                        <div class="card">
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Course Name</th>
                                            <th>Standard Fee (₹)</th>
                                            <th>Duration</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="course-list-table">
                                        <tr>
                                            <td colspan="4" class="text-center">Loading courses...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="batches-pane" role="tabpanel" aria-labelledby="batches-tab">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h3 class="mb-0">Manage Batches</h3>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBatchModal">
                                <i class="bi bi-plus-lg"></i> Add New Batch
                            </button>
                        </div>

                        <div class="card">
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Batch Name</th>
                                            <th>Course</th>
                                            <th>Start Date</th>
                                            <th>Seats</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="batch-list-table">
                                        <tr>
                                            <td colspan="5" class="text-center">Loading batches...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="pipeline-pane" role="tabpanel" aria-labelledby="pipeline-tab">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h3 class="mb-0">Edit Admissions Funnel Stages</h3>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStageModal">
                                <i class="bi bi-plus-lg"></i> Add New Stage
                            </button>
                        </div>
                        <div class="alert alert-info">
                            Drag and drop the stages below to re-order your Kanban board columns.
                        </div>

                        <ul class="list-group list-group-flush" id="pipeline-stages-list">
                        </ul>
                    </div>

                    <div class="tab-pane fade" id="users-pane" role="tabpanel" aria-labelledby="users-tab">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h3 class="mb-0">Manage CRM Users</h3>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                <i class="bi bi-person-plus-fill"></i> Invite New User
                            </button>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="user-list-table">
                                        <tr>
                                            <td colspan="5" class="text-center">Loading users...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="custom-fields-pane" role="tabpanel" aria-labelledby="custom-fields-tab">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h3 class="mb-0">Custom Fields for Leads</h3>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCustomFieldModal">
                                <i class="bi bi-plus-lg"></i> Add New Field
                            </button>
                        </div>
                        <div class="alert alert-warning">
                            Adding fields here requires database changes and an update to the Student Profile UI.
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Field Name</th>
                                            <th>Key (DB Column)</th>
                                            <th>Type</th>
                                            <th>Scoring</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="custom-fields-list-table">
                                        <tr>
                                            <td colspan="5" class="text-center">Loading fields...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="integrations-pane" role="tabpanel" aria-labelledby="integrations-tab">
                        <h3 class="mb-4">Lead Capture Integrations</h3>
                        <p class="text-muted">Connect your external platforms to automatically push leads into the CRM.</p>

                        <div class="card mb-3" data-platform="meta">
                            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                                <i class="bi bi-meta me-2"></i> Meta Lead Ads (Facebook/Instagram)
                                <span id="meta-connection-status" class="badge bg-danger">Disconnected</span>
                            </div>
                            
                            <div class="card-body">
                                <h5>Connection</h5>
                                <p>Connect your account to fetch ad data, lead forms, and metrics. You need to grant `leads_retrieval`, `ads_read`, and `pages_manage_ads` permissions.</p>
                                <button class="btn btn-primary" id="meta-login-button">
                                    <i class="bi bi-facebook me-2"></i> Connect with Facebook
                                </button>
                                <p id="auth-status-message" class="text-muted small mt-2 d-none">Initializing Meta SDK...</p>

                                <hr class="mt-4">
                                <h5>Lead Form Field Mapping</h5>
                                <p class="text-muted small">Map fields from your Meta Lead Forms to fields in your CRM.</p>
                                
                                <form id="meta-mapping-form">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Meta Field Name (Source)</th>
                                                    <th>CRM Field Key (Target)</th>
                                                </tr>
                                            </thead>
                                            <tbody id="meta-mapping-table">
                                                <tr><td colspan="2" class="text-center text-muted">Load Meta Forms to map fields.</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <button type="submit" class="btn btn-success btn-sm mt-2" id="save-mapping-button" disabled>
                                        Save Field Mapping
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="card mb-3" data-platform="website_form">
                            <div class="card-header bg-secondary text-white">
                                <i class="bi bi-browser-chrome me-2"></i> Website Contact Form
                            </div>
                            <form class="p-3 integration-form" data-platform-id="website_form">
                                <input type="hidden" name="platform" value="website_form">
                                <div class="mb-3">
                                    <label class="form-label">Webhook URL</label>
                                    <input type="text" class="form-control" readonly value="[Your CRM Base URL]/api/v1/webhook.php?key=[AUTO GENERATED KEY]">
                                    <small class="form-text text-muted">Use this URL in your website's form submission logic.</small>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="website_is_active" name="is_active" checked>
                                        <label class="form-check-label" for="website_is_active">Integration Active</label>
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-primary">Save Website Settings</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="bulk-import-pane" role="tabpanel" aria-labelledby="bulk-import-tab">
                        <h3 class="mb-4">Bulk Import Leads from CSV/TSV</h3>
                        <p class="text-muted">Import leads by providing a file link or uploading a local file.</p>
                        
                        <a href="#" id="download-sample-csv" class="btn btn-sm btn-outline-info mb-3">
                            <i class="bi bi-file-earmark-arrow-down me-1"></i> Download Sample CSV File
                        </a>

                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title">1. Source Data</h5>
                                <form id="bulk-import-form">
                                    
                                    <div id="url-input-group" class="mb-3">
                                        <label for="google_sheet_link" class="form-label">URL Link (Google Sheet Publish Link)</label>
                                        <input type="url" class="form-control" id="google_sheet_link" name="google_sheet_link" placeholder="e.g., https://docs.google.com/spreadsheets/d/.../export?format=csv">
                                    </div>
                                    <div id="file-input-group" class="mb-3">
                                        <label for="csv_file_upload" class="form-label">Local CSV/TSV File</label>
                                        <input type="file" class="form-control" id="csv_file_upload" name="csv_file_upload" accept=".csv, .tsv, .txt">
                                    </div>
                                    
                                    <h5 class="card-title mt-4">2. Field Mapping</h5>
                                    <p class="text-muted small">Map the columns from your source (Source) to the fields in the CRM (Target). **Full Name** and **Phone Number** are required.</p>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Source Column Header</th>
                                                    <th>CRM Field Key (Target)</th>
                                                </tr>
                                            </thead>
                                            <tbody id="import-mapping-table">
                                                <tr><td colspan="2" class="text-center text-muted">Enter data above and click Load to see columns.</td></tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div id="import-status-alert" class="alert d-none mt-3" role="alert"></div>

                                    <div class="text-end">
                                        <button type="button" class="btn btn-secondary me-2" id="load-columns-button" onclick="handleLoadColumns()">Load Columns</button>
                                        <button type="submit" class="btn btn-primary" id="start-import-button" disabled>Start Bulk Import</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
            </div>
        </div>

    </main>

    <div class="modal fade" id="addCourseModal" tabindex="-1" aria-labelledby="addCourseModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCourseModalLabel">Add New Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="add-course-form">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="course_name" class="form-label">Course Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="course_name" name="course_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="standard_fee" class="form-label">Standard Fee (₹) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" class="form-control" id="standard_fee" name="standard_fee" required>
                        </div>
                        <div class="mb-3">
                            <label for="duration" class="form-label">Duration (e.g., "6 Months")</label>
                            <input type="text" class="form-control" id="duration" name="duration">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Course</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addBatchModal" tabindex="-1" aria-labelledby="addBatchModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addBatchModalLabel">Create New Batch</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="add-batch-form">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="batch_name" class="form-label">Batch Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="batch_name" name="batch_name" required placeholder="e.g., FS-J24-A">
                        </div>
                        <div class="mb-3">
                            <label for="course_id" class="form-label">Course <span class="text-danger">*</span></label>
                            <select class="form-select" id="batch-course-id" name="course_id" required>
                                <option value="">-- Select Course --</option>
                                </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="start_date" class="form-label">Start Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="start_date" name="start_date" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="total_seats" class="form-label">Total Seats <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="total_seats" name="total_seats" required min="1">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Batch</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addStageModal" tabindex="-1" aria-labelledby="addStageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addStageModalLabel">Add New Pipeline Stage</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="add-stage-form">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="stage_name" class="form-label">Stage Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="stage_name" name="stage_name" required placeholder="e.g., Follow-up Sent, Scheduled Demo">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Stage</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">Invite New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="add-user-form">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="user_full_name" name="full_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username (Login ID) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Temporary Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="counselor">Counselor</option>
                                <option value="trainer">Trainer</option>
                                <option value="owner">Owner</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Invite User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addCustomFieldModal" tabindex="-1" aria-labelledby="addCustomFieldModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCustomFieldModalLabel">Define New Lead Field</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="add-custom-field-form">
                    <input type="hidden" name="field_id" id="field_id_input">
                    <input type="hidden" name="scoring_rules_json_hidden" id="scoring_rules_json_hidden"> <div class="modal-body">
                        <div class="mb-3">
                            <label for="field_name" class="form-label">Display Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="field_name" name="field_name" required placeholder="e.g., Expected Salary">
                        </div>
                        <div class="mb-3">
                            <label for="field_key" class="form-label">Database Key (Alpha-numeric, auto-slugged)</label>
                            <input type="text" class="form-control" id="field_key" name="field_key" placeholder="e.g., expected_salary">
                            <small class="text-muted">Used as the column name in the database.</small>
                        </div>
                        <div class="mb-3">
                            <label for="field_type" class="form-label">Field Type <span class="text-danger">*</span></label>
                            <select class="form-select" id="field_type" name="field_type" required onchange="toggleFieldSections()">
                                <option value="text">Text Input</option>
                                <option value="number">Number Input</option>
                                <option value="select">Dropdown (Select)</option>
                            </select>
                        </div>
                        <div class="mb-3 d-none" id="field-options-group">
                            <label for="options" class="form-label">Dropdown Options (Comma-Separated) <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="options" name="options" rows="2" placeholder="e.g., High, Medium, Low"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_required" id="is_required">
                                    <label class="form-check-label" for="is_required">Required Field</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_score_field" id="is_score_field">
                                    <label class="form-check-label" for="is_score_field">Use for Lead Scoring</label>
                                
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3 d-none" id="score-rules-panel">
                            <label class="form-label">Configure Lead Scoring Rules</label>
                            <p class="text-muted small">Enter comma-separated values that correspond to each score level.</p>

                            <div class="card card-body p-2 mb-2 border-success">
                                <label for="rules-high" class="form-label mb-1 text-success">High Score (100 pts)</label>
                                <textarea class="form-control form-control-sm score-input-rules" id="rules-high" data-level="High" rows="2" placeholder="e.g., Fresher, M.Tech"></textarea>
                            </div>

                            <div class="card card-body p-2 mb-2 border-warning">
                                <label for="rules-medium" class="form-label mb-1 text-warning">Medium Score (50 pts)</label>
                                <textarea class="form-control form-control-sm score-input-rules" id="rules-medium" data-level="Medium" rows="2" placeholder="e.g., 2-4 Years Exp, BSc"></textarea>
                            </div>

                            <div class="card card-body p-2 mb-2 border-info">
                                <label for="rules-low" class="form-label mb-1 text-info">Low Score (25 pts)</label>
                                <textarea class="form-control form-control-sm score-input-rules" id="rules-low" data-level="Low" rows="2" placeholder="e.g., 5+ Years Exp, Career Gap"></textarea>
                            </div>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Field Definition</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


   
    
    <script src="/assets/js/settings_integrations.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/settings_courses.js"></script>
    <script src="/assets/js/settings_pipeline.js"></script>
    <script src="/assets/js/settings_users.js"></script>
    <script src="/assets/js/settings_batches.js"></script>
    <script src="/assets/js/settings_custom_fields.js"></script>
    <script src="/assets/js/settings_import.js"></script>
    
    <script>
        // CRITICAL: App ID used for SDK initialization
        window.META_APP_ID = '1170946974995892'; 

        // Load the Meta SDK asynchronously
        window.fbAsyncInit = function() {
            FB.init({
                appId      : window.META_APP_ID,
                cookie     : true,
                xfbml      : true,
                version    : 'v19.0', 
                status     : true, // IMPORTANT: Attempts to get login status on init
                oauth      : true  // IMPORTANT: Enables OAuth flow handling
            });
            
            // After initialization, check connection status
            checkMetaConnectionStatus();
        };

        // Load the SDK script
        (function(d, s, id){
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) {return;}
            js = d.createElement(s); js.id = id;
            
            // NOTE: Using window.location.protocol ensures the SDK loads using HTTPS
            // when running via Ngrok, mitigating persistent caching errors.
            js.src = window.location.protocol + "//connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>
    
</body>

</html>