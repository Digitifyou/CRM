<?php
// SECURITY CHECK: Ensure user is logged in
require_once __DIR__ . '/api/config.php'; 

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.html');
    exit;
}
// Retrieve user details from session for display
$user_name = $_SESSION['full_name'] ?? 'Admin User';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .kpi-card {
            min-height: 120px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Training Academy CRM</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" href="/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/students.php">Students</a></li>
                    <li class="nav-item"><a class="nav-link" href="/enrollments.php">Enrollments</a></li>
                    <li class="nav-item"><a class="nav-link" href="/settings.php">Settings</a></li>
                    <li class="nav-item"><a class="nav-link" href="/meta_ads.php">Meta Ads</a></li>
                </ul>
                <a href="/logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <main class="container-fluid px-4">
        <h2 class="mb-4">Welcome, <?php echo $user_name; ?>!</h2>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card kpi-card bg-info text-white shadow">
                    <div class="card-body">
                        <h5 class="card-title">New Inquiries</h5>
                        <h3 class="card-text" id="kpi-inquiries-today">0</h3>
                        <p class="card-text"><small id="kpi-inquiries-week">0 this week</small></p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card kpi-card bg-success text-white shadow">
                    <div class="card-body">
                        <h5 class="card-title">Total Enrollments (MoM)</h5>
                        <h3 class="card-text" id="kpi-enrollments">0</h3>
                        <p class="card-text"><small>This month</small></p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card kpi-card bg-warning text-dark shadow">
                    <div class="card-body">
                        <h5 class="card-title">Inquiry-to-Enrollment %</h5>
                        <h3 class="card-text" id="kpi-conversion">0%</h3>
                        <p class="card-text"><small>Rolling month</small></p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card kpi-card bg-primary text-white shadow">
                    <div class="card-body">
                        <h5 class="card-title">Fees Collected (MoM)</h5>
                        <h3 class="card-text" id="kpi-fees">₹0</h3>
                        <p class="card-text"><small>This month</small></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-7 mb-4">
                <div class="card shadow">
                    <div class="card-header">
                        Admissions Pipeline Funnel (Open Deals)
                    </div>
                    <div class="card-body">
                        <canvas id="admissionsFunnelChart" style="max-height: 400px;"></canvas>
                        <div class="text-center text-muted mt-3" id="funnel-loading">Loading funnel data...</div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 mb-4">
                <div class="card shadow">
                    <div class="card-header">
                        Upcoming Batch Status
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Batch</th>
                                    <th>Course</th>
                                    <th>Start Date</th>
                                    <th>Seats</th>
                                </tr>
                            </thead>
                            <tbody id="batch-status-table">
                                <tr><td colspan="4" class="text-center text-muted">Loading batches...</td></tr>
                            </tbody>
                        </table>
                        
                        <h6 class="mt-4">Quick Links</h6>
                        <ul class="list-group">
                            <li class="list-group-item"><a href="/students.php">
                                <i class="bi bi-person-plus me-2"></i> View All Leads/Students</a>
                            </li>
                            <li class="list-group-item"><a href="/enrollments.php">
                                <i class="bi bi-bar-chart me-2"></i> Manage Enrollment Pipeline</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/dashboard-charts.js" defer></script>
</body>

</html>